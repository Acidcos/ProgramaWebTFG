<html>
<head>
  <title>Conversor de ficheros VHD para practicas con CPLD</title>
  <link rel="shortcut icon" href="logo.png">
  <link rel="stylesheet" type="text/css" href="./index.css" />
</head>

<form action="inicio.php" method="post" enctype="multipart/form-data" class="centrado">
<p>El archivo se ha subido correctamente</p>
  <input type="submit" class="boton" value="Volver">
</form>
<body>
</html>
