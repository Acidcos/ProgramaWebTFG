cd /var/www/html/ConversorCPLD/Archivos/$1/Sintesis
/opt/Xilinx/14.7/ISE_DS/ISE/bin/lin64/hprep6 -i Top.vm6
/opt/Xilinx/14.7/ISE_DS/ISE/bin/lin64/impact -batch /var/www/html/ConversorCPLD/Gen_XSVF.batch