<html>
<head>
  <title>Conversor de ficheros VHD para practicas con CPLD</title>
  <link rel="shortcut icon" href="logo.png">
  <link rel="stylesheet" type="text/css" href="./index.css" />
</head>
<body>
<form action="inicio.php" method="post" enctype="multipart/form-data" class="centrado">
  <p>No se encuentra el archivo con formato UCF</p>
  <input type="submit"  class="boton" value="Volver">
</form>
</body>
</html>