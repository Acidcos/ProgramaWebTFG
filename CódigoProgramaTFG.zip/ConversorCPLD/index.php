<!DOCTYPE html>
<html lang="es">
<head>
  <title>Conversor de ficheros VHD para practicas con CPLD</title>
  <link rel="shortcut icon" href="logo.png">
  <link rel="stylesheet" type="text/css" href="./index.css" />
</head>
<body>
  <p class="centrado"> Generador de archivos</p>
  <form action="inicio.php" method="post" enctype="multipart/form-data" class="centrado" >
    <input class="boton" type="submit" name="submit" value="Iniciar Practica">
  </form>
</body>
</html>