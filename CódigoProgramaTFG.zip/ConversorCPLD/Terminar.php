<?php
session_start();
//print_r($_POST['si']);
if (isset($_POST['si'])) {
    $fichero_dir = "./Archivos/" . session_id();
    /*  if (is_dir($fichero_dir)) {

        $files = glob($fichero_dir . "/*"); //obtenemos todos los nombres de los ficheros de ese directorio 
        //print_r($files);
        foreach ($files as $file) {
            if (is_file($file))
                unlink($file); //elimino el fichero
        }
        rmdir($fichero_dir);
    }*/
    exec("sudo ./Borrar_Todo.sh " . session_id());
    //rmdir($fichero_dir);


    session_destroy();
    header("Location:index.php");
} else {
    header("Location:inicio.php");
}



function rrmdir($dir)
{
    array_map('unlink', array_filter((array) glob($dir)));


    /*  if (is_dir($dir)) { 
      $objects = scandir($dir);
      foreach ($objects as $object) { 
        if ($object != "." && $object != "..") { 
          if (is_dir($dir. DIRECTORY_SEPARATOR .$object) && !is_link($dir."/".$object))
            rrmdir($dir. DIRECTORY_SEPARATOR .$object);
          else
            unlink($dir. DIRECTORY_SEPARATOR .$object); 
        } 
      }
      rmdir($dir); 
    } */
}
