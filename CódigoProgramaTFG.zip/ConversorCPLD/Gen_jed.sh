#cd /var/www/html/ConversorCPLD/Archivos/cin4nhl739br71cqvuase25n83
#cd /var/www/html/ConversorCPLD/Archivos/$1
#mkdir -p ./Sintesis && cp Top.ucf ./Sintesis
#cp ./Archivos/lrkgotdtbduv63tfmk0vlqjv3s/Top.ucf ./Archivos/lrkgotdtbduv63tfmk0vlqjv3s/directorioprueba/
cd /opt/Xilinx/14.7/ISE_DS/ISE/bin/lin64/
#/opt/Xilinx/14.7/ISE_DS/ISE/bin/lin64/
./xflow -p XC2C32A-6-VQ44 -synth xst_vhdl.opt -fit balanced.opt -wd /var/www/html/ConversorCPLD/Archivos/$1/Sintesis /var/www/html/ConversorCPLD/Archivos/$1/Top.prj
#./xflow -p XC2C256-7-TQ144 -synth xst_vhdl.opt -fit balanced.opt -wd /var/www/html/ConversorCPLD/Archivos/$1/Sintesis /var/www/html/ConversorCPLD/Archivos/$1/Top.prj
#./xflow -p XC2C256-7-TQ144 -synth cpld.flw -fit cpld.flw -wd /var/www/html/ConversorCPLD/Archivos/cin4nhl739br71cqvuase25n83/Sintesis /var/www/html/ConversorCPLD/Archivos/cin4nhl739br71cqvuase25n83/Top.prj
#./xflow -p XC2C256-7-TQ144 -synth xst_vhdl.opt -fit balanced.opt /var/www/html/ConversorCPLD/Archivos/cin4nhl739br71cqvuase25n83/Top.prj