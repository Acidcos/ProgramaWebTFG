<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <title>Conversor de ficheros VHD para practicas con CPLD</title>
    <link rel="shortcut icon" href="logo.png">
    <link rel="stylesheet" type="text/css" href="./index.css" />
</head>

<body>
    <form action="Terminar.php" method="post" enctype="multipart/form-data" class="centrado">
        <p> ¿Estas seguro de que quieres acabar la sesion y borrar todos los datos? </p>
        <input type="submit" class="boton" name="si" value="Si">
        <input type="submit" class="boton" name="no" value="No">

    </form>
</body>

</html>