<?php
session_start();
//header("Location: BorrarArchivos.php");
$fichero_dir = "./Archivos/" . session_id() . "/";
//$fichero_tipo = $fichero_dir . basename($_FILES["archivodeeds"]["name"]);
//$exito = 1;
//$fichero = strtolower(pathinfo($fichero_tipo,PATHINFO_EXTENSION));
if (isset($_POST['submit'])) {
  $fileTmpPath = $_FILES['fileToUpload']['tmp_name'];
  $fileName = $_FILES['fileToUpload']['name'];
  $fileSize = $_FILES['fileToUpload']['size'];
  $fileType = $_FILES['fileToUpload']['type'];
  $fileNameCmps = explode(".", $fileName);
  $fileExtension = strtolower(end($fileNameCmps));
  //print_r($_FILES);
  //print_r($fileExtension);
  if ($fileExtension != "ucf") {
    //$exito = 0;
    header("Location:error_ucf.php");
  } else {
    // directory in which the uploaded file will be moved
    $dest_path = $fichero_dir . $fileNameCmps[0] . "." . $fileNameCmps[1];
    if (move_uploaded_file($fileTmpPath, $dest_path)) {
      header("Location:exito.php");
    }
  }
}
