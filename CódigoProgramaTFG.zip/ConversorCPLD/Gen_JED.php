<?php
session_start();
$fichero_dir = "./Archivos/" . session_id() . "/";
//$fichero_dir2 = "./Archivos/";
copy($fichero_dir . "Sintesis/" . 'Top.ucf', $fichero_dir . 'Top.ucf');

$file = fopen($fichero_dir . "Top.prj", "w");

foreach (glob($fichero_dir . "*.vhd") as $file2) { //EL PROBLEMA ES AQUI, NO PUEDO DEJAR EL DIRECTORIO, SOLO ME QUEDO CON EL NOMBRE
    fputs($file, 'vhdl work "');
    fputs($file, basename($file2));
    fputs($file, '"');
    fputs($file, "\n");
}

fclose($file);

//exec("Gen_jed.sh");

$file_ucf = $fichero_dir . "Top.ucf";
//S$file_jed = $fichero_dir . "Top.jed";

if (file_exists($file_ucf)) {

    exec("sudo ./Gen_jed.sh " . session_id());
    exec("sudo ./permisos.sh " . session_id());
    exec("sudo ./Gen_jed2.sh " . session_id());
    //exec("./Gen_XSVF.sh " . session_id());
    //echo "./Gen_jed.sh " . session_id();
    $file_jed = $fichero_dir . 'Sintesis/Top.jed';
    if (file_exists($file_jed)) {
        //header("Content-disposition: attachment; filename=Top.jed");
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_jed) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_jed));
        readfile($file_jed);



        //readfile($fichero_dir . "Top.jed"); 
        //echo 'Se ha descargado el fichero de configuracion';
    } else {
       header("Location:error_jed.php");
    }
} else {
    header("Location:error_ucf2.php");
}
