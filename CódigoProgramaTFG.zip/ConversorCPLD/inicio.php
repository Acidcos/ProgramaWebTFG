<?php
session_start();
$fichero_dir = "./Archivos/" . session_id();
borradirectorio("./Archivos");
if (!is_dir($fichero_dir)) {
  mkdir($fichero_dir);
  mkdir($fichero_dir . "/Sintesis");
}


include("inicio.html");

function borradirectorio($fichero_dir)
{

  if (is_dir($fichero_dir)) {

    $files = glob($fichero_dir . "/*"); //obtenemos todos los nombres de los ficheros de ese directorio 
    //print_r($files);
    foreach ($files as $file) {
      if (is_dir($file)) {
        $fechamod = filemtime($file);
        $dias = floor((time() - $fechamod) / 86400);
        //echo "dias transcurridos " . $dias . " del directorio " . $file;
        if ($dias >= 1)
          exec("sudo ./Borrar_Todo2.sh " . $file); //Si cambio el 1 del if puedo reducir o aumentar la antiguedad de los ficheros que querer borrar
      }
    }
    // rmdir($fichero_dir);
  }
}
