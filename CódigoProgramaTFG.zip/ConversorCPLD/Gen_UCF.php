<?php
session_start();
$fichero_dir = "./Archivos/" . session_id() . "/";
//unlink('.\Archivos\Top.ucf');
$archivo = fopen($fichero_dir . "Sintesis/" . 'Top.ucf', 'w');
for ($i = 1; $i < 50; $i++) {
    $var = 'pin' . $i;
    if (isset($_POST[$var])&& !empty($_POST[$var])) {
        fputs($archivo, 'pin "');
        fputs($archivo, $_POST[$var]);
        fputs($archivo, '"');
        fputs($archivo, " ");
        fputs($archivo, 'LOC = "S:');
        fputs($archivo, $var);
        fputs($archivo, '"');
        fputs($archivo, ';');
        fputs($archivo, "\r\n");
    }
   
}
    fclose($archivo);
    copy($fichero_dir . "Sintesis/" . 'Top.ucf' , $fichero_dir . 'Top.ucf');

/*$pin1 = $_POST['pin1'];
$pin2 = $_POST['pin2'];
$pin3 = $_POST['pin3'];
$pin4 = $_POST['pin4'];
$pin5 = $_POST['pin5'];
$pin6 = $_POST['pin6'];
$pin7 = $_POST['pin7'];
$pin8 = $_POST['pin8'];
$pin9 = $_POST['pin9'];
$pin10 = $_POST['pin10'];
$pin11 = $_POST['pin11'];
$pin12 = $_POST['pin12'];
$pin13 = $_POST['pin13'];
$pin14 = $_POST['pin14'];
$pin15 = $_POST['pin15'];
$pin16 = $_POST['pin16'];
$loc1 = $_POST['LOC1'];
$loc2 = $_POST['LOC2'];
$loc3 = $_POST['LOC3'];
$loc4 = $_POST['LOC4'];
$loc5 = $_POST['LOC5'];
$loc6 = $_POST['LOC6'];
$loc7 = $_POST['LOC7'];
$loc8 = $_POST['LOC8'];
$loc9 = $_POST['LOC9'];
$loc10 = $_POST['LOC10'];
$loc11 = $_POST['LOC11'];
$loc12 = $_POST['LOC12'];
$loc13 = $_POST['LOC13'];
$loc14 = $_POST['LOC14'];
$loc15 = $_POST['LOC15'];
$loc16 = $_POST['LOC16'];
$archivo = fopen($fichero_dir . 'Top.ucf', 'w');
if (!empty($pin1)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin1);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc1);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin2)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin2);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc2);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin3)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin3);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc3);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin4)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin4);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc4);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin5)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin5);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc5);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin6)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin6);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc6);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin7)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin7);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc7);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin8)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin8);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc8);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin9)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin9);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc9);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin10)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin10);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc10);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin11)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin11);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc11);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin12)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin12);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc12);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin13)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin13);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc13);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin14)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin14);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc14);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin15)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin15);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc15);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}
if (!empty($pin16)) {
    fputs($archivo, 'pin "');
    fputs($archivo, $pin16);
    fputs($archivo, '"');
    fputs($archivo, " ");
    fputs($archivo, 'LOC = "S:');
    fputs($archivo, $loc16);
    fputs($archivo, '"');
    fputs($archivo, ';');
    fputs($archivo, "\r\n");
}*/
//fclose($archivo);
Header("Location: inicio.php");
